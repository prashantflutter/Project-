

List<String> adSliderImg = [
  'assets/slider/ad1.png',
  'assets/slider/ad2.png',
  'assets/slider/ad3.png',
  'assets/slider/ad4.png',
];