
const hireEm = 'assets/buttonIcons/employee.png';
const hireEm2 = 'assets/buttonIcons/employee2.png';
const find = 'assets/buttonIcons/find.png';
const postJob = 'assets/buttonIcons/post.png';
const event = 'assets/buttonIcons/event.png';
const ad1 = '';
