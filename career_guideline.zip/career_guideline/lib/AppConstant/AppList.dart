

List<String> images = [
  'assets/slider/slide1.jpg',
  'assets/slider/slide2.jpg',
  'assets/slider/slide3.jpg',
  'assets/slider/slide4.png',
];

List<String> courseNameList = ['10th','12th','Graduate','Post\nGraduate'];
List<String> courseNameIMGList = ['10th','12th','Graduate','Post Graduate'];

List course1 = ['Class XI-XII Arts','Class XI-XII Commerce','Class XI-XII Science','Diploma Courses','Polytechnic Courses','Medical & Paramedical Courses' ,'Vocational Courses','ITI Courses'];