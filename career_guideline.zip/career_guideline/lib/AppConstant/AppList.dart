

List<String> images = [
  'assets/slider/slide1.jpg',
  'assets/slider/slide2.jpg',
  'assets/slider/slide3.jpg',
  'assets/slider/slide4.png',
];

List<String> courseNameList = ['10th','12th','Graduate','Post\nGraduate'];
List<String> courseNameIMGList = ['10th','12th','Graduate','Post Graduate'];

List course1 = ['Class XI-XII Arts','Class XI-XII Commerce','Class XI-XII Science','Diploma Courses','Polytechnic Courses','Medical & Paramedical Courses' ,'Vocational Courses','ITI Courses'];

List eligibilityTitle = ['Qualification :','Minimum Marks :','Nationality :','Compulsory Subjects :'];
List eligibilityDec = ['Should have passed class 10th or 12th','Candidates should have obtained 40% marks in the qualifying examination. (Note: Minimum marks can vary from institute to institute)','Should be of Indian National','Generally Mathematics, Science & English are considered to be compulsory polytechnic subjects to apply for diploma courses'];
List PolytechnicCareers = ['Civil Engineering Technician','Electrical Engineering Technician','Mechanical Engineering Technician', 'Computer Technician','Electronics and Communication Technician', 'Automobile Technician','Chemical Process Technician','Interior Designer','Hotel Manager','Fashion Designer'];
List AverageSalary = ['Salary Range: ₹2,00,000 - ₹5,00,000 per year',
  'Salary Range: ₹2,20,000 - ₹5,50,000 per year',
  'Salary Range: ₹2,20,000 - ₹5,50,000 per year',
  'Salary Range: ₹2,20,000 - ₹6,00,000 per year',
  'Salary Range: ₹2,20,000 - ₹5,50,000 per year',
  'Salary Range: ₹2,20,000 - ₹5,50,000 per year',
  'Salary Range: ₹2,20,000 - ₹6,00,000 per year',
  'Salary Range: ₹1,50,000 - ₹4,00,000 per year',
  'Salary Range: ₹1,50,000 - ₹4,00,000 per year',
  'Salary Range: ₹1,50,000 - ₹4,00,000 per year',
];
























