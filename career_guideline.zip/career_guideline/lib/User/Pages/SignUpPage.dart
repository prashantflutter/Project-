import 'package:careerguideline/AppConstant/Appcolors.dart';
import 'package:careerguideline/User/Pages/LoginPage.dart';
import 'package:flutter/material.dart';
import '../../Widgets/ButtonWidgets.dart';
import '../../Widgets/MyAppBar.dart';
import '../../Widgets/TextFormWidgets.dart';


class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<SignUpPage> {

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController cPasswordController = TextEditingController();

  ValueNotifier changeValue = ValueNotifier<int>(0);
  ValueNotifier changeValue2 = ValueNotifier<int>(0);

  bool isPassword = true;
  bool isCPassword = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: MyAppBar(
        automaticallyImplyLeading: false,
        title: 'User Signup',),
      body: ValueListenableBuilder(
        valueListenable: changeValue,
        builder: (context,value,child) {
          return Column(
            children: [
              MyTextForm(controller: nameController, hintText: 'Name'),
              MyTextForm(controller: emailController, hintText: 'Email'),
              MyTextForm(controller: passwordController, hintText: 'Password',obscureText: isPassword,
                suffixIcon: IconButton(onPressed: (){
                  isPassword = !isPassword;
                  changeValue.value++;
                }, icon: Icon(isPassword?Icons.visibility_outlined:Icons.visibility_off_outlined,color: pDark,))
              ),
              MyTextForm(controller: cPasswordController, hintText: 'Confirm Password',obscureText: isPassword,
                suffixIcon: IconButton(onPressed: (){
                  isCPassword = !isCPassword;
                  changeValue.value++;
                }, icon: Icon(isCPassword?Icons.visibility_outlined:Icons.visibility_off_outlined,color: pDark,),),
              ),
              MyButton(onPressed: (){

              }, title: 'Login'),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: MyTextButton(title: 'already account | login', onPressed: ()=>
                    Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()))),
              ),
            ],
          );
        }
      ),
    );
  }

}
