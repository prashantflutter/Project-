import 'package:flutter/material.dart';

import '../AppConstant/AppTextStyle.dart';

Widget myTitle({required String data}){
  return  Padding(
    padding: EdgeInsets.symmetric(vertical: 5),
    child: Text(data,style: textStyle.copyWith(fontSize: 20,fontWeight: FontWeight.w700),),
  );
}

Widget myDescription({required String data}){
  return   Padding(
    padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
    child: Text(data,style: textStyle.copyWith(fontSize: 18),),
  );
}